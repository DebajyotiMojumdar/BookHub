package com.sandy.bookhub.fragments


import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sandy.bookhub.dataClass.Book
import com.sandy.bookhub.adaptor.DashboardAdaptor
import com.sandy.bookhub.R
import com.sandy.bookhub.R.*
import org.json.JSONException


class DashBoard : Fragment() {
    lateinit var dashBoardRecyclerView: RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var relativeProgress:RelativeLayout

    val bookInfoList= arrayListOf<Book>()

    lateinit var dashboardAdaptor: DashboardAdaptor



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view=inflater.inflate(layout.fragment_dash_board, container, false)
        relativeProgress=view.findViewById(R.id.relativeProgress)
        relativeProgress.visibility=View.VISIBLE

        val queue=Volley.newRequestQueue(activity as Context)
        val link="http://13.235.250.119/v1/book/fetch_books/"
        val jsonObjectRequest = object :JsonObjectRequest(Request.Method.GET,link,null,Response.Listener {

            try {
                val success = it.getBoolean("success")
                if(success)
                {
                    relativeProgress.visibility=View.GONE
                    val dataArray = it.getJSONArray("data")
                    for (i in 0 until  dataArray.length()) {
                        val bookObject = dataArray.getJSONObject(i)
                        val book = Book(
                            bookObject.getString("book_id"),
                            bookObject.getString("name"),
                            bookObject.getString("author"),
                            bookObject.getString("rating"),
                            bookObject.getString("price"),
                            bookObject.getString("image")
                        )
                        bookInfoList.add(book)

                    }
                        dashBoardRecyclerView= view.findViewById(R.id.dashRecycler)
                        layoutManager=LinearLayoutManager(activity)
                        dashboardAdaptor=
                            DashboardAdaptor(
                                activity as Context,
                                bookInfoList
                            )
                        dashBoardRecyclerView.layoutManager=layoutManager
                        dashBoardRecyclerView.adapter=dashboardAdaptor




                }
                else
                    Toast.makeText(activity as Context,"Some error happend",Toast.LENGTH_SHORT).show()
            }
            catch (ex: JSONException)
            {
                Toast.makeText(activity as Context,"some error occured",Toast.LENGTH_SHORT).show()
            }

        },
            Response.ErrorListener {

                val dialog=AlertDialog.Builder(activity as Context)

                dialog.setTitle("Error")
                dialog.setMessage("Internet Connection Not Found")
                dialog.setPositiveButton("Open Settings"){
                        text, listner ->
                    val settingIntent=Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    startActivity(settingIntent)
                    activity?.finish()

                }
                dialog.setNegativeButton("Exit"){
                        text,listner->
                    ActivityCompat.finishAffinity(activity as Activity)
                }

                dialog.create()
                dialog.show()



            }){
            override fun getHeaders(): MutableMap<String, String> {
                val headers=HashMap<String,String>()
                headers["Content-type"]="application/json"
                headers["token"]="4c90c79eae1fe0"

                return headers
            }
        }

        queue.add(jsonObjectRequest)


        return view
    }


}
