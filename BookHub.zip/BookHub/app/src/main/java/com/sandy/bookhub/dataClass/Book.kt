package com.sandy.bookhub.dataClass

data class Book(
                val bookId:String,
                val bookName:String,
                val author:String,
                val rating:String,
                val price:String,
                val bookImage:String)