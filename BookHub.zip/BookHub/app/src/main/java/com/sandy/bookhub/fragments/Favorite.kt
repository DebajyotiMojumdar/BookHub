package com.sandy.bookhub.fragments


import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.sandy.bookhub.R
import com.sandy.bookhub.adaptor.FavoriteAdaptor
import com.sandy.bookhub.database.BookEntities
import com.sandy.bookhub.database.Database

class Favorite : Fragment() {

    lateinit var recyclerView: RecyclerView
    lateinit var favoriteAdaptor: FavoriteAdaptor
    lateinit var relativeLayout: RelativeLayout
    lateinit var layoutManager: RecyclerView.LayoutManager
    var listBooks=listOf<BookEntities>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view=inflater.inflate(R.layout.fragment_favorite, container, false)
        recyclerView=view.findViewById(R.id.favRecycler)
        relativeLayout=view.findViewById(R.id.favProgress)
        relativeLayout.visibility=View.VISIBLE
        layoutManager= GridLayoutManager(activity,2)
        listBooks=RetrieveFavorites(activity as Context).execute().get()

        if (activity!=null)
        {
            relativeLayout.visibility=View.GONE
            favoriteAdaptor= FavoriteAdaptor(activity as Context,listBooks)
            recyclerView.layoutManager=layoutManager
            recyclerView.adapter=favoriteAdaptor
        }
        else
        {
            Toast.makeText(context,"error occured",Toast.LENGTH_SHORT).show()
        }




        return view
    }

    class RetrieveFavorites(val context: Context):AsyncTask<Void,Void,List<BookEntities>>() {
        override fun doInBackground(vararg params: Void?): List<BookEntities> {
            val db= Room.databaseBuilder(context,Database::class.java,"books-db").build()
            val books=db.bookDao().getAllBooks()
            return books
        }
    }

    override fun onResume() {
        favoriteAdaptor.notifyDataSetChanged()
        recyclerView=view!!.findViewById(R.id.favRecycler)
        relativeLayout=view!!.findViewById(R.id.favProgress)
        relativeLayout.visibility=View.VISIBLE
        layoutManager= GridLayoutManager(activity,2)
        listBooks=RetrieveFavorites(activity as Context).execute().get()

        if (activity!=null)
        {
            relativeLayout.visibility=View.GONE
            favoriteAdaptor= FavoriteAdaptor(activity as Context,listBooks)
            recyclerView.layoutManager=layoutManager
            recyclerView.adapter=favoriteAdaptor
        }
        else
        {
            Toast.makeText(context,"error occured",Toast.LENGTH_SHORT).show()
        }
        super.onResume()
    }


}
