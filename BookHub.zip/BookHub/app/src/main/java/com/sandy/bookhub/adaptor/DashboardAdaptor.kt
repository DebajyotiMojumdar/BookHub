package com.sandy.bookhub.adaptor

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sandy.bookhub.dataClass.Book
import com.sandy.bookhub.R
import com.sandy.bookhub.activity.DescriptionActivity
import com.squareup.picasso.Picasso

class DashboardAdaptor (val context: Context,val itemList:ArrayList<Book>):RecyclerView.Adapter<DashboardAdaptor.DashboardViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.book_single_row,parent,false)
        return DashboardViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
        val book=itemList[position]
        holder.bookId=book.bookId
        holder.tvBookName.text=book.bookName
        holder.tvAuthor.text=book.author
        holder.tvPrice.text=book.price
        holder.tvRating.text=book.rating
        Picasso.get().load(book.bookImage).error(R.drawable.default_book_cover).into(holder.imgBook)


        holder.tvRelativeLayout.setOnClickListener{
            println("bookId ${holder.bookId}")
            val intent= Intent(context, DescriptionActivity::class.java)
            intent.putExtra("bookId",holder.bookId)
            context.startActivity(intent)
        }

    }


    class DashboardViewHolder(view: View):RecyclerView.ViewHolder(view)
    {
        lateinit var bookId:String
        val imgBook:ImageView =view.findViewById(R.id.imgBook)
        val tvBookName:TextView=view.findViewById(R.id.tvbookName)
        val tvAuthor:TextView=view.findViewById(R.id.tvAuthor)
        val tvPrice:TextView=view.findViewById(R.id.tvPrice)
        val tvRating:TextView=view.findViewById(R.id.tvRating)
        val tvRelativeLayout:RelativeLayout=view.findViewById(R.id.tvRelativeLayout)
    }
}