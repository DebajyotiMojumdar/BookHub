package com.sandy.bookhub.activity

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sandy.bookhub.R
import com.sandy.bookhub.adaptor.FavoriteAdaptor
import com.sandy.bookhub.database.BookEntities
import com.sandy.bookhub.database.Database
import com.sandy.bookhub.fragments.DashBoard
import com.sandy.bookhub.fragments.Favorite
import com.sandy.bookhub.util.ConnectionManager
import com.squareup.picasso.Picasso
import org.json.JSONException
import org.json.JSONObject

class DescriptionActivity : AppCompatActivity() {

    lateinit var toolbar: Toolbar
    lateinit var progress: ProgressBar
    lateinit var progressLayout: RelativeLayout
    lateinit var imgView: ImageView
    lateinit var tvBookName: TextView
    lateinit var tvBookAuthor: TextView
    lateinit var tvBookPrice: TextView
    lateinit var tvBookRating: TextView
    lateinit var tvBookDescribe:TextView
    lateinit var btnAddFav:Button
    var bookId: String? = "100"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)
        toolbar = findViewById(R.id.descriptionToolbar)
        progressLayout = findViewById(R.id.descRelaytive)
        imgView = findViewById(R.id.imgDescBook)
        tvBookName = findViewById(R.id.tvDescbookName)
        tvBookAuthor = findViewById(R.id.tvDescAuthor)
        tvBookPrice = findViewById(R.id.tvDescPrice)
        tvBookRating = findViewById(R.id.tvDescRating)
        btnAddFav=findViewById(R.id.btnAddFav)
        tvBookDescribe=findViewById(R.id.tvBookDescribe)
        progressLayout.visibility = View.VISIBLE

        setSupportActionBar(toolbar)
        supportActionBar?.title="Book Description"

        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)




        if (intent != null)
            bookId = intent.getStringExtra("bookId")
        else
            Toast.makeText(this@DescriptionActivity,"error occured in intent",Toast.LENGTH_SHORT).show()
        if (bookId=="100") {
            finish()
            Toast.makeText(this@DescriptionActivity,"error occured in id",Toast.LENGTH_SHORT).show()
        }

        if (ConnectionManager().checkConectivity(this@DescriptionActivity)) {
                val queue = Volley.newRequestQueue(this@DescriptionActivity)
                val url = "http://13.235.250.119/v1/book/get_book/"
                val jsonParam = JSONObject()
                jsonParam.put("book_id", bookId)
                println("desc $bookId")
                val jsonObjectRequest =
                    object : JsonObjectRequest(Request.Method.POST, url, jsonParam,
                        Response.Listener {

                            println("response $it")

                            try {
                                if (it.getBoolean("success"))
                                {
                                    val bookJsonObj = it.getJSONObject("book_data")
                                    progressLayout.visibility = View.GONE
                                    val imageurl=bookJsonObj.getString("image")
                                    Picasso.get().load(bookJsonObj.getString("image")).error(R.drawable.default_book_cover).into(imgView)
                                    tvBookName.text=bookJsonObj.getString("name")
                                    tvBookAuthor.text=bookJsonObj.getString("author")
                                    tvBookPrice.text=bookJsonObj.getString("price")
                                    tvBookRating.text=bookJsonObj.getString("rating")
                                    tvBookDescribe.text=bookJsonObj.getString("description")

                                    val bookEntities=BookEntities(bookJsonObj.getString("book_id").toInt(),
                                        tvBookName.text.toString(),
                                        tvBookAuthor.text.toString(),
                                        tvBookPrice.text.toString(),
                                        tvBookRating.text.toString(),
                                        tvBookDescribe.text.toString(),
                                        imageurl


                                    )

                                    val checkFav=
                                        DbAsync(
                                            applicationContext,
                                            bookEntities,
                                            1
                                        ).execute()
                                    val isFav=checkFav.get()

                                    if(isFav)
                                    {
                                        btnAddFav.text="Remove from favorites"
                                    }

                                    else{
                                        btnAddFav.text="Add to favorites"
                                    }

                                    btnAddFav.setOnClickListener {


                                        if(isFav)
                                        {
                                            val asyncTask=
                                                DbAsync(
                                                    applicationContext,
                                                    bookEntities,
                                                    3
                                                ).execute()
                                            val result=asyncTask.get()
                                            if(result)
                                            {
                                                btnAddFav.text="Add to favorites"
                                                Toast.makeText(this@DescriptionActivity,"Book removed from favorites",Toast.LENGTH_SHORT).show()
                                            }
                                            else
                                            {
                                                Toast.makeText(this@DescriptionActivity,"error in removing",Toast.LENGTH_SHORT).show()

                                            }
                                        }
                                        else{

                                            val asyncTask=
                                                DbAsync(
                                                    applicationContext,
                                                    bookEntities,
                                                    2
                                                ).execute()
                                            val result=asyncTask.get()
                                            if(result)
                                            {
                                                btnAddFav.text="Remove from favorite"
                                                Toast.makeText(this@DescriptionActivity,"Book added to favorites",Toast.LENGTH_SHORT).show()
                                            }
                                            else
                                            {
                                                Toast.makeText(this@DescriptionActivity,"error in adding",Toast.LENGTH_SHORT).show()

                                            }
                                        }



                                    }


                                }
                                else
                                    Toast.makeText(this@DescriptionActivity,"obj error occured",Toast.LENGTH_SHORT).show()
                            }
                            catch (e:JSONException)
                            {
                                Toast.makeText(this@DescriptionActivity,"json error occured",Toast.LENGTH_SHORT).show()
                            }


                        },
                        Response.ErrorListener {

                            Toast.makeText(this@DescriptionActivity,"error occured",Toast.LENGTH_SHORT).show()


                        }) {

                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["content-type"] = "application/json"
                            headers["token"] = "4c90c79eae1fe0"
                            return headers
                        }
                    }
            queue.add(jsonObjectRequest)


            }
        else
        {
            val dialog=AlertDialog.Builder(this@DescriptionActivity)

            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection Not Found")
            dialog.setPositiveButton("Open Settings"){
                    text, listner ->
                val settingIntent=Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingIntent)
                finish()

            }
            dialog.setNegativeButton("Exit"){
                    text,listner->
                ActivityCompat.finishAffinity(this@DescriptionActivity)
            }

            dialog.create()
            dialog.show()


        }



    }

    class DbAsync(val context: Context,val bookEntities: BookEntities,val mode:Int):AsyncTask<Void,Void,Boolean>(){

        val db= Room.databaseBuilder(context,Database::class.java,"books-db").build()
        override fun doInBackground(vararg params: Void?): Boolean {

            when(mode)
            {
                1->{

                    val book:BookEntities?=db.bookDao().getBookById(bookEntities.bookId.toString())
                    db.close()
                    return book!=null


                }
                2->{
                    db.bookDao().bookInsert(bookEntities)
                    db.close()
                    return true


                }
                3->{
                    db.bookDao().bookDelete(bookEntities)
                    db.close()
                    return true

                }
            }

            return false
        }

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId == android.R.id.home)
        {
            this.finish()

            return true

        }
        else
            return super.onOptionsItemSelected(item)
    }


}