package com.sandy.bookhub.adaptor

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sandy.bookhub.R
import com.sandy.bookhub.activity.DescriptionActivity
import com.sandy.bookhub.database.BookEntities
import com.squareup.picasso.Picasso


class FavoriteAdaptor(val context:Context,val bookList:List<BookEntities>) :RecyclerView.Adapter<FavoriteAdaptor.FavoriteViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view=LayoutInflater.from(context).inflate(R.layout.favorite_single_element,parent,false)
        return FavoriteViewHolder(view)

    }


    override fun getItemCount(): Int {
        return bookList.size

    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {

        val book=bookList[position]
        holder.bookId=book.bookId.toString()
        Picasso.get().load(book.bookImage).error(R.drawable.default_book_cover).into(holder.imgBook)
        holder.tvBookName.text=book.bookName
        holder.tvAuthor.text=book.bookAuthor
        holder.tvPrice.text=book.bookPrice
        holder.tvRating.text=book.bookRating

        holder.tvRelativeLayout.setOnClickListener{
            val intent= Intent(context,DescriptionActivity::class.java)
            intent.putExtra("bookId",holder.bookId)
            context.startActivity(intent)

        }


    }


    class FavoriteViewHolder(view: View):RecyclerView.ViewHolder(view)
    {
        lateinit var bookId:String
        val imgBook: ImageView =view.findViewById(R.id.imgfav)
        val tvBookName: TextView =view.findViewById(R.id.tvfavName)
        val tvAuthor: TextView =view.findViewById(R.id.tvfavAuthor)
        val tvPrice: TextView =view.findViewById(R.id.tvfavPrice)
        val tvRating: TextView =view.findViewById(R.id.tvfavRating)
        val tvRelativeLayout: RelativeLayout =view.findViewById(R.id.favRelativeLayout)

    }
}